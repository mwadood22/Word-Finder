#pragma once
namespace Project1 {
	bool match_case, match_word, found = false;

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	using namespace System::Text;

	void compute_Prefix_Func(String^ pat, int M, int* prfx);
	void KMPMatcher(String^ pat, String^ txt, int count)
	{
		int M = pat->Length, N = txt->Length, k = 0, i = 0, j = 0, temp=0, z = 0;
		String^ wrd;
		Char tmp;
		String^ line = count.ToString();
		int* prfx = new int[M];
		compute_Prefix_Func(pat, M, prfx);
		while (i < N)
		{
			z = i;	
			if (temp == 0)
			{
				while (txt[z] != ' ')
				{
					tmp = txt[z];
					wrd += tmp.ToString();
					z++;
					if (z >= N)
						break;
				}
			}
			if (match_case == false)
			{
				Char first = pat[j];
				Char second = txt[i];
				int decimalValue_pat = (int)first;
				int decimalValue2_txt = (int)second;
				int decimalValue3_pat;
				if (decimalValue_pat > 90)
				{
					decimalValue3_pat = decimalValue_pat - 32;
				}
				if (decimalValue_pat == decimalValue2_txt || decimalValue3_pat == decimalValue2_txt)
				{
					
					temp++;
					j++;
					i++;
				}
			}
			else if (match_case == true)
			{
				if (pat[j] == txt[i])
				{
					j++;
					i++;
				}
			}
			if (j == M && match_word == true)
			{
				if (k == 0)
				{
					if (txt[j] == ' ')
					{
						found = true;
						MessageBox::Show(String::Format("Word found at line no: {0}", line));
						MessageBox::Show(String::Format("Word: {0}", pat));
					}
				}
				else if (k != 0 && i < N)
				{
					if (txt[i - (j+1)] == ' ' && txt[i+1] == ' ')
					{
						found = true;
						MessageBox::Show(String::Format("Word found at line no: {0}", line));
						MessageBox::Show(String::Format("Word: {0}", pat));
					}
				}
				else if (k != 0 && i == N)
				{
					
					if (txt[i - (j+1)] == ' ')
					{
						found = true;
						MessageBox::Show(String::Format("Word found at line no: {0}", line));
						MessageBox::Show(String::Format("Word: {0}", pat));
						
					}
				}
				j = prfx[j - 1];
				k++;
				temp = 0;
				tmp = ' ';
				wrd = tmp.ToString();
			}
			else if (j == M && match_word == false)
			{
				found = true;
				MessageBox::Show(String::Format("Word found at line no: {0}", line));
				MessageBox::Show(String::Format("Word: {0}", wrd));
				j = prfx[j - 1];
			}
			
			else if (i < N && pat[j] != txt[i])
			{
				if (j != 0)
				{
					j = prfx[j - 1];
				}
				else
					i = i + 1;
				temp = 0;
				tmp = ' ';
				wrd = tmp.ToString();
			}
		}
	}
		void compute_Prefix_Func(String^ pat, int M, int* prfx)
		{
			int len = 0;
			prfx[0] = 0;
			int i = 1;
			while (i < M)
			{
				if (pat[i] == pat[len]) {
					len++;
					prfx[i] = len;
					i++;
				}
				else
				{
					if (len != 0)
					{
						len = prfx[len - 1];
					}
					else
					{
						prfx[i] = 0;
						i++;
					}
				}
			}
		}
	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected:
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::CheckBox^  checkBox1;
	private: System::Windows::Forms::CheckBox^  checkBox2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(67, 34);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(56, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Find what:";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(129, 27);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(188, 20);
			this->textBox1->TabIndex = 1;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(334, 26);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(62, 20);
			this->button1->TabIndex = 2;
			this->button1->Text = L"&Find Next";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(334, 60);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(61, 19);
			this->button2->TabIndex = 3;
			this->button2->Text = L"Cancel";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Location = System::Drawing::Point(12, 86);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(135, 17);
			this->checkBox1->TabIndex = 4;
			this->checkBox1->Text = L"Match whole word only";
			this->checkBox1->UseVisualStyleBackColor = true;
			this->checkBox1->CheckedChanged += gcnew System::EventHandler(this, &MyForm::checkBox1_CheckedChanged);
			// 
			// checkBox2
			// 
			this->checkBox2->AutoSize = true;
			this->checkBox2->Location = System::Drawing::Point(12, 109);
			this->checkBox2->Name = L"checkBox2";
			this->checkBox2->Size = System::Drawing::Size(82, 17);
			this->checkBox2->TabIndex = 5;
			this->checkBox2->Text = L"Match case";
			this->checkBox2->UseVisualStyleBackColor = true;
			this->checkBox2->CheckedChanged += gcnew System::EventHandler(this, &MyForm::checkBox2_CheckedChanged);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(405, 138);
			this->Controls->Add(this->checkBox2);
			this->Controls->Add(this->checkBox1);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label1);
			this->Name = L"MyForm";
			this->Text = L"Find";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^e) 
	{

	}
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^e) 
	{
		int no_of_line = 0, i = 1;
		StreamReader^ input_file = File::OpenText("test.txt");

		String^ line;
		String^ temp;
		String^ find = textBox1->Text;

		input_file = File::OpenText("test.txt");
			while ((line = input_file->ReadLine()) != nullptr)
			{
				if (find->Length != 0)
				{
					KMPMatcher(find, line, i);
					i++;
				}
			}
		if (input_file)
		{
			input_file ->Close();
		}
		if( found == false)
		MessageBox::Show("Word not found!");
	}
private: System::Void checkBox1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) 
{
	if (checkBox1->Checked)
	{
		match_word = true;
	}
	else
	{
		match_word = false;
	}
}
private: System::Void checkBox2_CheckedChanged(System::Object^  sender, System::EventArgs^  e) 
	{
	if (checkBox2->Checked)
	{
		match_case = true;
	}
	else
	{
		match_case = false;
	}
	}
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) 
{
	this->Close();
}
};
}
